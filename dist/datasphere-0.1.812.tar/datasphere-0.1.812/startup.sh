#! /bin/bash
java -classpath bin/classes:lib/*:. datasphere.catalog.DSMain $@